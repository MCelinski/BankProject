#include <iostream>
#include <fstream>
#include <cstdlib>
#include <conio.h>

using namespace std;
class Auta{
    public:

    string marka;
    string model;
    float poj;
    int przebieg;



    void zapis();
    void odczyt();
};
