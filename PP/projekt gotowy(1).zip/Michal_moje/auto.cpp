#include <iostream>
#include <fstream>
#include <cstdlib>
#include <conio.h>
#include<vector>
#include "main.h"

    void Auta::zapis(){
        system( "cls" );
        fstream dane;
        dane.open("dane.txt",ios::ate | ios::in);

        cout << " Podaj marke: ";
        cin >> marka;
        dane  << marka << endl;

        cout << " Podaj model: ";
        cin >> model;
        dane  << model << endl;

        cout << " Podaj pojemnosc:";
        cin >> poj;
        dane  << poj << endl ;

        cout << " Podaj przebieg:";
        cin >> przebieg;
        dane  << przebieg << endl;

    dane.close();
    }



